import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import translationEN from "./locales/en.json"; 
import translationAR from "./locales/ar.json";

const resources = {
  en: { translation: translationEN },
  ar: { translation: translationAR },
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources,
    fallbackLng: "en",
    lng: "ar",
    interpolation: { escapeValue: false },
  });

document.documentElement.dir = i18n.language === 'ar' ? 'rtl' : 'ltr';
export default i18n;